#!/system/bin/sh
MODDIR=${0%/*}

# Değişkenler
REAL_DIR="/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content"

umount "$REAL_DIR" 2>/dev/null
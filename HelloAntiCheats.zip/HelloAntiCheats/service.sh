#!/system/bin/sh
MODDIR=${0%/*}

REAL_DIR="/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content"

if ! mount | grep -q "$REAL_DIR"; then
    FAKE_DIR="$MODDIR/system/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content"
    mount -o bind "$FAKE_DIR" "$REAL_DIR" 2>/dev/null
fi

if pgrep -f "com.tencent.ig" >/dev/null; then
    :
fi
#!/system/bin/sh
REAL_PROC="/proc"
REAL_SYS="/sys"
REAL_PROP="/system/build.prop"

umount "$REAL_PROC" "$REAL_SYS" "$REAL_PROP" 2>/dev/null
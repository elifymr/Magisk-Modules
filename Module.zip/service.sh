#!/system/bin/sh
MODDIR=${0%/*}

# Değişkenler
FAKE_PROC="$MODDIR/system/proc/empty"
FAKE_SYS="$MODDIR/system/sys/empty"
FAKE_PROP="$MODDIR/system/prop/local.prop"
REAL_PROC="/proc"
REAL_SYS="/sys"
REAL_PROP="/system/build.prop"

if pgrep -f "com.tencent.ig" >/dev/null; then
    if ! mount | grep -q "$REAL_PROC"; then
        mount -o bind "$FAKE_PROC" "$REAL_PROC" 2>/dev/null
    fi
    if ! mount | grep -q "$REAL_SYS"; then
        mount -o bind "$FAKE_SYS" "$REAL_SYS" 2>/dev/null
    fi
    if ! mount | grep -q "$REAL_PROP"; then
        mount -o bind "$FAKE_PROP" "$REAL_PROP" 2>/dev/null
    fi
    logcat -s "com.tencent.ig" > /sdcard/devicescan_log.txt 2>&1 &
fi